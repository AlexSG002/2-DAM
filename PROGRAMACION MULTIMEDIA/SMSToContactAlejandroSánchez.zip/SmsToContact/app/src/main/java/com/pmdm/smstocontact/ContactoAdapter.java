package com.pmdm.smstocontact;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ContactoAdapter extends BaseAdapter {
    //Declaramos el contexto para el adaptador
    private Context contexto;
    //Declaramos una lista de contactos.
    private ArrayList<Contacto> listaContactos;

    // Constructor de la clase
    public ContactoAdapter(Context contexto, ArrayList<Contacto> listaContactos) {
        this.contexto = contexto;
        this.listaContactos = listaContactos;
    }
    //Obtenemos el número de objetos, la posición y el id de cada uno de ellos y la vista para ponerlo en la listview.
    @Override
    public int getCount() {
        return listaContactos.size();
    }

    @Override
    public Object getItem(int position) {
        return listaContactos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Si la vista obtenida es nula, es decir no se ha añadido la añade y la obtiene del contexto de la clase.
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(contexto);
            //Infla la vista con de items con el item por defecto.
            convertView = inflater.inflate(R.layout.listview_item, parent, false);
        }
        //Obtenemos un contacto
        Contacto contacto = listaContactos.get(position);
        //Establecemos los campos del item por defecto con los datos de cada contacto.
        TextView textViewNombre = convertView.findViewById(R.id.textViewNombre);
        TextView textViewNumero = convertView.findViewById(R.id.textViewNumero);
        ImageView imageViewFoto = convertView.findViewById(R.id.imageViewFoto);
        //Establecemos el nombre completo del contacto para que aparezca al estar separado por nombre y apellido.
        String nombreCompleto = contacto.getNombre() + " " + contacto.getApellido();
        textViewNombre.setText(nombreCompleto);
        textViewNumero.setText(contacto.getNumero());
        //Obtenemos la foto del contacto siempre que tenga foto, si no la tiene establecemos la foto por defecto (yo he puesto este iconito de android).
        if (contacto.getUriFoto() != null) {
            imageViewFoto.setImageURI(Uri.parse(contacto.getUriFoto()));
            if (imageViewFoto.getDrawable() == null) {
                imageViewFoto.setImageResource(R.drawable.ic_launcher_foreground);
            }
        } else {
            imageViewFoto.setImageResource(R.drawable.ic_launcher_foreground);
        }
        //Si hacemos onlongclick en uno de los contactos nos va a los detalles de contacto.
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (contexto instanceof MainActivity) {
                    ((MainActivity) contexto).irADetallesContacto(contacto);
                }
                return true;
            }
        });
        //Devolvemos el contacto en la lista.
        return convertView;
    }
    //Método para actualizar la lista de contactos.
    public void actualizarListaContactos(ArrayList<Contacto> nuevosContactos) {
        this.listaContactos = nuevosContactos;
        notifyDataSetChanged();
    }
}
