package com.pmdm.smstocontact;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class DetallesContacto extends DialogFragment {
    //Declaramos las variables que vamos a utilzar, también inicializo la key para los datos de contacto.
    private static final String DATOS_CONTACTO = "DATOS";
    //Declaramos un contacto para obtener los argumentos del parcelable.
    private Contacto contacto;
    private Button buttonEnviarMensaje;
    private Button buttonEnviar;
    private EditText editTextMensaje;
    //Declaramos como instancia de detalles de contacto como lo recibido del parcelable.
    public static DetallesContacto newInstance(Contacto contacto) {
        DetallesContacto fragment = new DetallesContacto();
        Bundle args = new Bundle();
        args.putParcelable(DATOS_CONTACTO, contacto);
        fragment.setArguments(args);
        return fragment;
    }
    //Al crearse la vista de dialogo inflamos el fragmento de detalles del contacto.
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_detalles_contacto, container, false);
    }
    //Una vez se ha creado la vista.
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //Si los argumentos del parcelable son nulos los obtenemos con la key.
        if (getArguments() != null) {
            contacto = getArguments().getParcelable(DATOS_CONTACTO);
        }
        //Declaramos e inicializamos las variables de los campos de detalles.
        ImageView imageView = view.findViewById(R.id.imageViewFotoDetalles);
        TextView textViewName = view.findViewById(R.id.textViewNombreDetalles);
        TextView textViewNumber = view.findViewById(R.id.textViewNumeroDetalles);
        //Declaramos e inicializamos los botones y el editText del mensaje.
        buttonEnviarMensaje = view.findViewById(R.id.buttonEnviarMensaje);
        buttonEnviar = view.findViewById(R.id.buttonEnviar);
        editTextMensaje = view.findViewById(R.id.editTextMensaje);
        //Al hacer clic en enviar mensaje aparecen los botones de enviar y el de el campo mensaje.
        buttonEnviarMensaje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonEnviar.setVisibility(View.VISIBLE);
                editTextMensaje.setVisibility(View.VISIBLE);
                //Obtenemos los detalles de la ventana para modificar el tamaño para cuando aparezcan el campo de texto y el botón de envío.
                Window ventana = getDialog().getWindow();
                WindowManager.LayoutParams params = ventana.getAttributes();
                params.height = (int) (getResources().getDisplayMetrics().heightPixels * 0.8);
                ventana.setAttributes(params);
            }
        });
        //Al pulsar el botón ejecutamos el método enviarSMS de la MainActivity.
        buttonEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Obtenemos el mensaje del editText.
                String mensaje = editTextMensaje.getText().toString().trim();
                //Mientras el mensaje no este vacío.
                if (!mensaje.isEmpty()) {
                    //Obtenemos la instancia de MainActivity y ejecutamos el método de enviarSMS.
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).enviarSMS(contacto, mensaje);
                        //Una vez envíado salimos de los detalles del contacto.
                        dismiss();
                    } else {
                        //En caso de error para manejar excepciones.
                        Toast.makeText(getContext(), "Error al enviar el mensaje", Toast.LENGTH_SHORT).show();
                    }
                    //Mensaje de error en caso de que el mensaje este vacío.
                } else {
                    Toast.makeText(getContext(), "El mensaje está vacío", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //Si el contacto no es nulo obtenemos los datos y los establecemos en los campos del objeto por defecto.
        if (contacto != null) {
            String nombreCompleto = contacto.getNombre() + " " + contacto.getApellido();
            textViewName.setText(nombreCompleto);
            textViewNumber.setText(contacto.getNumero());

            if (contacto.getUriFoto() != null) {
                imageView.setImageURI(Uri.parse(contacto.getUriFoto()));
                if (imageView.getDrawable() == null) {
                    imageView.setImageResource(R.drawable.ic_launcher_foreground);
                }
            } else {
                imageView.setImageResource(R.drawable.ic_launcher_foreground);
            }
        }
    }
    //Al crearse la ventana de dialogo modificamos el tamaño para que se ajuste a los datos del principio
    @Override
    public void onStart() {
        super.onStart();
        if(getDialog()!=null){
            Window ventana = getDialog().getWindow();
            if(ventana!=null){
                WindowManager.LayoutParams params = ventana.getAttributes();
                params.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.9);
                params.height = (int) (getResources().getDisplayMetrics().heightPixels * 0.35);
                ventana.setAttributes(params);
            }
        }
    }
}
