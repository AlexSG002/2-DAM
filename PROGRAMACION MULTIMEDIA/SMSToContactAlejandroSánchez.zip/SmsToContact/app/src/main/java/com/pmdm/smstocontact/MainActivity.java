package com.pmdm.smstocontact;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import android.Manifest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Declaramos las variables a usar.
    private LinearLayout ll;
    //Inicializamos también el codigo con el que comprobaremos que se han concedido los permisos necesarios.
    private final int CODIGO_PERMISO_LEER_CONTACTOS = 1;
    private final int CODIGO_PERMISO_ENVIAR_SMS = 1;
    private ListView listViewContactos;
    private ContactoAdapter contactoAdapter;
    private EditText editTextNombre;
    private EditText editTextApellido;
    private Button buttonFiltrarNombre;
    private Button buttonFiltrarApellido;
    private Button buttonSeleccionar;
    private Button buttonBorrarCampos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Inicializamos las variables que vamos a utilizar, los botones, el linearlayout para inflar la vista y los editText.
        buttonSeleccionar = findViewById(R.id.buttonSeleccionar);
        ll = findViewById(R.id.linearLayout);
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextApellido = findViewById(R.id.editTextApellido);
        buttonFiltrarNombre = findViewById(R.id.buttonFiltrarNombre);
        buttonFiltrarApellido = findViewById(R.id.buttonFiltrarApellido);
        buttonBorrarCampos = findViewById(R.id.buttonLimpiarCampos);

        //Comprobamos si se han permitido los permisos de sms y si no los solicita.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, CODIGO_PERMISO_ENVIAR_SMS);
        }
        //Método que se ejecuta al hacer clic en seleccionar contactos.
        buttonSeleccionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Comprobamos si se han permitido los permisos de contacto y si no los solicita.
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_CONTACTS}, CODIGO_PERMISO_LEER_CONTACTOS);
                }
                //Establece como visible el linear layout y demás elementos escondidos que hemos declarado antes.
                ll.setVisibility(View.VISIBLE);
                buttonFiltrarApellido.setVisibility(View.VISIBLE);
                buttonFiltrarNombre.setVisibility(View.VISIBLE);
                editTextApellido.setVisibility(View.VISIBLE);
                editTextNombre.setVisibility(View.VISIBLE);
                buttonBorrarCampos.setVisibility(View.VISIBLE);
                //Le inflamos a la vista la lista de contactos que tenemos en el listview.
                LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                View listViewLayout = inflater.inflate(R.layout.listview, ll, false);

                listViewContactos = listViewLayout.findViewById(R.id.listViewContactos);
                //Buscamos en el arraylist de contactos los todos los contactos.
                ArrayList<Contacto> contactos = buscar("", "");
                //Mientras los contactos no sean nulos creamos un nuevo adaptador de contactos para establecer la listview.
                if (contactos != null) {
                    contactoAdapter = new ContactoAdapter(MainActivity.this, contactos);
                    listViewContactos.setAdapter(contactoAdapter);
                }
                //Añadimos la vista de la lista al contenedor es decir el linear layout que ya teníamos.
                ll.addView(listViewLayout);
            }
        });
        //Botón que ejecuta el método para filtrar por nombre
        buttonFiltrarNombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombreFiltro = editTextNombre.getText().toString().trim();
                String apellidoFiltro = "";

                //En caso de que el usuario introduzca números lo indicamos y salimos del método.
                if (validarEntrada(nombreFiltro)) {
                    Toast.makeText(MainActivity.this, "El nombre no puede contener números", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Buscamos en el array list de contactos por el nombre y apellido establecido, en este caso
                //el apellido es nulo y solo busca por nombre.
                ArrayList<Contacto> contactosFiltrados = buscar(nombreFiltro, apellidoFiltro);
                //Mientras exista el adaptador de contactos actualiza la lista de contactos con los contactos filtrados.
                if (contactoAdapter != null) {
                    contactoAdapter.actualizarListaContactos(contactosFiltrados);
                }
            }
        });
        //Lo mismo para los apellidos pero en este caso filtra por ambos.
        buttonFiltrarApellido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombreFiltro = editTextNombre.getText().toString().trim();
                String apellidoFiltro = editTextApellido.getText().toString().trim();

                if (validarEntrada(nombreFiltro)) {
                    Toast.makeText(MainActivity.this, "El nombre no puede contener números", Toast.LENGTH_SHORT).show();
                    return;
                }

                //La misma validación pero para apellidos.
                if (validarEntrada(apellidoFiltro)) {
                    Toast.makeText(MainActivity.this, "El apellido no puede contener números", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Obtenemos la lista de contactos filtrados buscando los contactos con el método buscar por nombre y apellido.
                ArrayList<Contacto> contactosFiltrados = buscar(nombreFiltro, apellidoFiltro);
                if (contactoAdapter != null) {
                    contactoAdapter.actualizarListaContactos(contactosFiltrados);
                }
            }
        });
        //Botón para borrar los campos.
        buttonBorrarCampos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextNombre.setText("");
                editTextApellido.setText("");
            }
        });

    }
    //Método para mostrar los detalles de un contacto al hacer on long clic en un contacto.
    public void irADetallesContacto(Contacto contacto) {
        DetallesContacto fragment = DetallesContacto.newInstance(contacto);
        fragment.show(getSupportFragmentManager(), "DATOS");
    }
    //Métodos para obtener los resultados de la solicitud de permisos.
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CODIGO_PERMISO_LEER_CONTACTOS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permiso concedido para leer contactos", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permiso denegado para leer contactos", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == CODIGO_PERMISO_ENVIAR_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permiso concedido para enviar SMS", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permiso denegado para enviar SMS", Toast.LENGTH_SHORT).show();
            }
        }
    }
    //Método para buscar en los contactos
    @SuppressLint("Range")
    //Busca a través de el nombre y apellido, y devuelve un arraylist de contactos.
    public ArrayList<Contacto> buscar(String nombre, String apellido) {
        //Declaramos e inicializamos el content resolver para obtener los resultados.
        ContentResolver cr = getContentResolver();
        //Creamos el arrayList.
        ArrayList<Contacto> listaContactos = new ArrayList<>();
        //Declaramos e inicializamos el cursor a la query de los contenidos de contactos, que los saca
        //de nuestro dispositivo.
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                new String[]{
                        ContactsContract.Contacts._ID,
                        ContactsContract.Contacts.DISPLAY_NAME,
                        ContactsContract.Contacts.HAS_PHONE_NUMBER,
                        ContactsContract.Contacts.PHOTO_URI
                },
                null,
                null,
                ContactsContract.Contacts.DISPLAY_NAME + " ASC");
        //Recorremos el cursor mientras hayan valores y no sea nulo.
        if (cur != null && cur.getCount() > 0) {
            while (cur.moveToNext()) {
                //Obtenemos los datos para utilizarlos.
                String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                String displayName = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                String photoUri = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.PHOTO_URI));
                //Creamos un array de strings simplemente para dividir el nombre, ya que no detecta nombre y apellidos por separado.
                String[] dividirNombre = displayName.split(" ", 2);
                String nombreContacto = dividirNombre.length > 0 ? dividirNombre[0] : "";
                String apellidoContacto = dividirNombre.length > 1 ? dividirNombre[1] : "";
                //Obtenemos el número de teléfono.
                String numeroTelefono = "";
                if (Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor cursorTelefono = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    if (cursorTelefono != null && cursorTelefono.moveToNext()) {
                        numeroTelefono = cursorTelefono.getString(cursorTelefono.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        cursorTelefono.close();
                    }
                }
                //Variables booleanas que utilizo para comprobar que el nombre introducido coincide con lo filtrado.
                boolean matchesNombre = nombre.isEmpty() || nombreContacto.toLowerCase().startsWith(nombre.toLowerCase());
                boolean matchesApellido = apellido.isEmpty() || apellidoContacto.toLowerCase().startsWith(apellido.toLowerCase());
                //Si coinciden nombre y apellido con el filtro de busqueda los crea como objeto con los datos obtenidos , es decir un nuevo Contacto y lo añade a la lista de contactos.
                if (matchesNombre && matchesApellido) {
                    Contacto contactoObjeto = new Contacto(id, nombreContacto, apellidoContacto, numeroTelefono, photoUri);
                    listaContactos.add(contactoObjeto);
                }
            }
            //Cerramos el cursor.
            cur.close();
        }
        //Devolvemos la lista de contactos.
        return listaContactos;
    }

    //Método para enviar el sms.
    public void enviarSMS(Contacto contacto, String mensaje) {
        //Obtenemos el número del contacto.
        String numeroTelefono = contacto.getNumero();

        if (numeroTelefono != null && !numeroTelefono.isEmpty()) {
            try {
                //Utilizamos SmsManager para mandar el mensaje.
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(numeroTelefono, null, mensaje, null, null);

                Toast.makeText(this, "SMS enviado a " + contacto.getNombre() + " " + contacto.getApellido(), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "No se pudo enviar el SMS", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "El contacto no tiene un número de teléfono válido.", Toast.LENGTH_SHORT).show();
        }

    }
    //Método para comprobar que el texto introducido no sean números.
    private boolean validarEntrada(String texto) {
        return texto.matches(".*\\d.*");
    }

}