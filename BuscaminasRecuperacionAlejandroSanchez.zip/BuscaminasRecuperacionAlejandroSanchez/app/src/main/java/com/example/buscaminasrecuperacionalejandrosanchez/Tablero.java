package com.example.buscaminasrecuperacionalejandrosanchez;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.Toast;


import androidx.gridlayout.widget.GridLayout;

import java.util.Random;
//Clase tablero que maneja toda la lógica de la partida.
public class Tablero {
    //Declaramos una matriz de objetos celda.
    private Celda[][] celdas;
    //Declaramos una matriz de enteros de nombre minas.
    private int[][] minas;
    //Declaramos un gridLayout.
    private GridLayout gl;
    //Declaramos una matriz booleana de nombre minasReveladas.
    private boolean[][] minasReveladas;
    //Declaramos el contexto.
    private Context context;
    //Constructor de la clase tablero.
    public Tablero(Context co, GridLayout gl, int x, int y, String emoji){
        //Inicializamos como gridLayout el que obtenemos como argumento.
        this.gl = gl;
        //Inicializamos como contexto el que obtenemos como argumento.
        context = co;
        //Borramos todas las vistas, y establecemos el número de filas y columnas, según la dificultad obtenida como argumento.
        gl.removeAllViews();
        gl.setRowCount(x);
        gl.setColumnCount(y);
        //Establecemos el fondo a negro, para distinguir mejor las celdas.
        gl.setBackgroundColor(Color.BLACK);
        //Inicializamos las celdas con el valor de las filas y columnas.
        celdas = new Celda[x][y];
        //Obtenemos el tamaño del grid layout
        int anchura = gl.getWidth();
        int altura = gl.getHeight();
        //Declaramos un margen para la separación entre las celdas.
        int margen = 2;
        //Calculamos la altura y anchura disponibles teniendo en cuenta los márgenes.
        int anchuraDisponible = anchura - (y * margen * 2);
        int alturaDisponible = altura - (x * margen * 2);
        //Obtenemos la altura y anchura de cada celda.
        int anchuraCelda = anchuraDisponible / y;
        int alturaCelda = alturaDisponible / x;
        //Inicializamos la variable de minas y minasReveladas.
        minasReveladas = new boolean[x][y];
        minas = new int[x][y];
        //Declaramos una variable para manejar la cantidad de minas.
        int cantidadMinas = 0;
        if(x == 8){
            cantidadMinas = 10;
        } else if (x == 12) {
            cantidadMinas = 30;
        } else if (x == 16) {
            cantidadMinas = 60;
        }
        //Generamos minas en función de la dificultad y la cantidad de minas.
        generarMinas(x, y, cantidadMinas);
        //Método de prueba para imprimir las minas y ver donde están.
        imprimirMinas(x, y);
        //Creamos unos for anidados para crear cada celda de manera individual a lo largo de la matriz.
        for(int fila = 0; fila < x; fila++){
            for(int columna = 0; columna < y; columna++){
                //Creamos una celda a la que le pasamos el contexto como argumento.
                Celda c = new Celda(co);
                //Modificamos los parámetros de la celda en relación a la altura, anchura, filas y columnas obtenidas.
                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = anchuraCelda;
                params.height = alturaCelda;
                params.rowSpec = GridLayout.spec(fila);
                params.columnSpec = GridLayout.spec(columna);
                //También establecemos los márgenes.
                params.setMargins(margen, margen, margen, margen);
                //Añadimos la vista de la celda al grid layout.
                gl.addView(c, params);
                //Establecemos como celda cada una de las celdas de la matriz de objetos celda.
                celdas[fila][columna] = c;
                //Declaramos e inicializamos las variables ultimaFila y ultimaColumna a las últimas filas y columnas a las que se hace referencia.
                int ultimaFila = fila;
                int ultimaColumna = columna;
                //Establecemos un OnClickListener a las celdas.
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Comprobamos si existe una mina en la últimaFila y últimaColumna, que es en la que hemos hecho clic.
                        if (minas[ultimaFila][ultimaColumna] == -1) {
                            //Si es una mina lo descubierto cambiamos el texto al emoji y cambiamos el color del fondo.
                            c.setText(emoji);
                            c.setBackgroundColor(Color.RED);
                            //Marcamos como revelada la mina.
                            minasReveladas[ultimaFila][ultimaColumna] = true;
                            //Le mandamos un mensaje de derrota al usuario.
                            pierdes("Has perdido porque has descubierto una mina.");
                            //Desactivamos la celda.
                            c.setEnabled(false);
                        } else {
                            //En caso de que no seas una mina revelamos la celda con un método.
                            revelarCelda(ultimaFila, ultimaColumna);
                            //Comprobamos victoria.
                            comprobarVictoria();
                        }
                    }
                });
                //Establecemos un OnLongClickListener a las celdas.
                c.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if(minasReveladas[ultimaFila][ultimaColumna]){
                            return true;
                        }
                        //Establecemos la bandera como texto.
                        c.setText("🚩");
                        //Comprobamos que exista una mina.
                        if (minas[ultimaFila][ultimaColumna] == -1){
                            //Cambiamos el fondo y establecemos la mina como revelada.
                            c.setBackgroundColor(Color.WHITE);
                            minasReveladas[ultimaFila][ultimaColumna] = true;
                            //Marcamos la celda como desactivada.
                            c.setEnabled(false);
                            //Comprobamos la victoria.
                            comprobarVictoria();
                            //Indicamos un mensaje de que se ha encontrado una mina.
                            Toast.makeText(context, "Has encontrado una mina",Toast.LENGTH_SHORT).show();
                        }else{
                            //En caso contrario establece el fondo a rojo ya que se ha puesto una bandera sobre una celda sin mina.
                            c.setBackgroundColor(Color.RED);
                            pierdes("Has perdido porque colocaste una bandera en una celda sin mina.");
                        }
                        return true;
                    }
                });

            }
        }

    }
    //Método para generar minas.
    private void generarMinas(int filas, int columnas, int cantidadMinas) {
        //Declaramos e inicializamos un nuevo random para generar enteros aleatorios.
        Random random = new Random();
        //Declaramos un entero de nombre minasColocadas que usaremos de contador.
        int minasColocadas = 0;
        //Mientras las minasColocadas sea menor que la cantidad de minas.
        while(minasColocadas < cantidadMinas){
            //Declaramos un numero de fila y columna aleatorio.
            int filaRandom = random.nextInt(filas);
            int columnaRandom = random.nextInt(columnas);
            //Comprobamos que no exista una mina en esa posición.
            if(minas[filaRandom][columnaRandom] !=-1){
                //Establecemos la mina.
                minas[filaRandom][columnaRandom] =-1;
                //Sumamos la mina.
                minasColocadas++;
            }
        }
    }
    //Método que imprime la matriz de las minas, para hacer pruebas.
    private void imprimirMinas(int filas, int columnas) {
        StringBuilder builder = new StringBuilder();
        for (int fila = 0; fila < filas; fila++) {
            for (int columna = 0; columna < columnas; columna++) {
                builder.append(minas[fila][columna] == -1 ? " M " : " V ");
            }
            builder.append("\n");
        }
        Log.d("imprimirMinas", builder.toString());
    }
    //Método que muestra un mensaje al perder.
    private void pierdes(String mensaje){
        new AlertDialog.Builder(context).setTitle("¡Has Perdido!")
                .setMessage(mensaje).setPositiveButton("Reiniciar", (dialog, which) -> {
                    ((MainActivity) context).reiniciarPartida();
                }).setCancelable(false).show();
    }

    //Método que comprueba la victoria, comprueba que todas las minas han sido marcadas recorriendo la matriz de celdas.
    private void comprobarVictoria() {
        boolean todasLasMinasMarcadas = true;

        for(int fila = 0; fila < celdas.length; fila++){
            for(int columna = 0; columna < celdas[fila].length; columna++){
                Celda celda = celdas[fila][columna];

                if(minas[fila][columna] == -1 && !minasReveladas[fila][columna]) {
                    if(!celda.getText().toString().equals("🚩")) {
                        todasLasMinasMarcadas = false;
                    }
                }
            }
        }
        if(todasLasMinasMarcadas) {
            ganaste();
        }
    }
    //Método que lanza un mensaje de victoria en caso de ganar y reinicia la partida.
    private void ganaste(){
        new AlertDialog.Builder(context)
                .setTitle("¡Felicidades!")
                .setMessage("¡Has ganado el juego! ¿Quieres jugar otra vez?")
                .setPositiveButton("Reiniciar", (dialog, which) -> {
                    ((MainActivity)context).reiniciarPartida();
                })
                .setCancelable(false)
                .show();
    }
    //Método para contar las minas alrededor de la descubierta.
    private int contarMinasAlrededor(int fila, int columna) {
        //Declaramos e incializamos un contador a 0.
        int cont = 0;
        //Creamos un bucle anidado para comprobar el movimiento de cada fila y columna adyacente.
        for (int movimientoFila = -1; movimientoFila <= 1; movimientoFila++) {
            for (int movimientoColumna = -1; movimientoColumna <= 1; movimientoColumna++) {
                if (!(movimientoFila == 0 && movimientoColumna == 0)) {
                    //Declaramos dos enteros y los inicializamos el movimiento de la fila y la columna.
                    int nuevaFila = fila + movimientoFila;
                    int nuevaColumna = columna + movimientoColumna;
                    //De manera que comprobamos el número de minas alrededor si es mayor o igual a 0 y menor que la cantidad de minas.
                    if (nuevaFila >= 0 && nuevaFila < minas.length && nuevaColumna >= 0 && nuevaColumna < minas[0].length) {
                        //Y existe una mina, la añadimos al contador.
                        if (minas[nuevaFila][nuevaColumna] == -1) {
                            cont++;
                        }
                    }
                }
            }
        }
        return cont;
    }
    //Método recursivo para revelar las celdas en caso de que no hayan minas cercanas.
    private void revelarCelda(int fila, int columna) {
        //Comprobamos que la fila y columna esté dentro de los rangos permitidos.
        if (fila < 0 || fila >= celdas.length || columna < 0 || columna >= celdas[0].length) {
            return;
        }
        //Comprobamos que la celda ya esté revelada y no sea una mina.
        if (minasReveladas[fila][columna] || minas[fila][columna] == -1) {
            return;
        }
        //Establecemos la celda como revelada.
        minasReveladas[fila][columna] = true;
        //Declaramos la celda como la celda de la fila y la columna de la matriz de celdas.
        Celda celda = celdas[fila][columna];
        //Declaramos el número de minas cercanas utilizando el método para contar las minas.
        int minasCercanas = contarMinasAlrededor(fila, columna);
        //Deshabilitamos la celda.
        celda.setEnabled(false);
        //Si las minas cercanas son mayores que 0 entonces simplemente revelamos esa casilla y establecemos como texto el número de minas cercanas.
        if (minasCercanas > 0) {
            celda.setText(String.valueOf(minasCercanas));
            celda.setBackgroundColor(Color.WHITE);
            //En caso contrario establecemos el texto como vacío y cambiamos el fondo de la celda.
        } else {
            celda.setText("");
            celda.setBackgroundColor(Color.WHITE);
            //Comprobamos las celdas alrededor de la que hemos pulsado
            for (int movimientoFila = -1; movimientoFila <= 1; movimientoFila++) {
                for (int movimientoColumna = -1; movimientoColumna <= 1; movimientoColumna++) {
                    //Mientras el movimiento de la fila y la columna sea distinto de cero.
                    if (!(movimientoFila == 0 && movimientoColumna == 0)) {
                        //Y ejecutamos de nuevo el método sobre esa celda.
                        revelarCelda(fila + movimientoFila, columna + movimientoColumna);
                    }
                }
            }
        }
    }


}
