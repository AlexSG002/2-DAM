package com.example.buscaminasrecuperacionalejandrosanchez;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;

import androidx.appcompat.widget.AppCompatButton;
//Clase celda que simplemente cuenta con los detalles de color de la celda.
//Implementamos la clase botón ya que actuará como tal.
public class Celda extends AppCompatButton {

    public Celda(Context co){
        super(co);
        setBackgroundColor(Color.LTGRAY);
        setTextColor(Color.BLACK);
        setGravity(Gravity.CENTER);

    }

}
