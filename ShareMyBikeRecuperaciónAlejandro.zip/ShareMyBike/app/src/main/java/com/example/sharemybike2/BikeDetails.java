package com.example.sharemybike2;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

//Fragmento que sirve para ver los detalles de la bici en la que hagamos clic.
public class BikeDetails extends Fragment {
    //Declaramos e inicializamos los argumentos de la bici con la key bici para obtener los resultados del parcelable.
    private static final String ARG_BIKE = "bike";
    //Declaramos un objeto bici.
    private BikesContent.Bike bike;
    //Declaramos los elementos que vamos a usar.
    private ImageView bikeImageView;
    private TextView ownerTextView;
    private TextView descriptionTextView;
    private TextView cityTextView;
    private TextView locationTextView;
    private TextView emailTextView;
    //Constructor.
    public BikeDetails() {
    }

    public static BikeDetails newInstance(BikesContent.Bike bike) {
        BikeDetails fragment = new BikeDetails();
        Bundle args = new Bundle();
        args.putParcelable(ARG_BIKE, bike);
        fragment.setArguments(args);
        return fragment;
    }
    //Si los argumentos recibidos no son nulos obtenemos el parcelable de la bici.
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            bike = getArguments().getParcelable(ARG_BIKE);
        }
    }
    //Al crearse la vista infla el fragmento de los detalles de bici.
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        return inflater.inflate(R.layout.fragment_bike_details, container, false);
    }
    //En vista creada.
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);
        //Inicializamos cada elemento al existente en el fragmento.
        bikeImageView = view.findViewById(R.id.detailsBikeImageView);
        ownerTextView = view.findViewById(R.id.detailsOwnerTextView);
        descriptionTextView = view.findViewById(R.id.detailsDescriptionTextView);
        cityTextView = view.findViewById(R.id.detailsCityTextView);
        locationTextView = view.findViewById(R.id.detailsLocationTextView);
        emailTextView = view.findViewById(R.id.detailsEmailTextView);
        //Si la bici no es nula obtenemos los datos.
        if (bike != null) {
            bikeImageView.setImageBitmap(bike.getPhoto());
            ownerTextView.setText(bike.getOwner());
            descriptionTextView.setText(bike.getDescription());
            cityTextView.setText(bike.getCity());
            locationTextView.setText(bike.getLocation());
            emailTextView.setText(bike.getEmail());
        }
    }
}
