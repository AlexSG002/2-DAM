package com.example.sharemybike2;


import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.RecyclerView;


import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MyItemRecyclerViewAdapter extends RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder> {
    //Declaramos una listas de bicis.
    private final List<BikesContent.Bike> mValues;
    //Declaramos el contexto.
    private final Context mContext;
    //Declaramos el id del canal de notificaciones.
    private final String CHANNEL_ID = "canal_notificaciones_bikeshare";
    //Declaramos un listener de click.
    private final OnItemClickListener mListener;
    //Creamos una interfaz de OnItemClickListener sobre los objetos bici.
    public interface OnItemClickListener {
        void onItemClick(BikesContent.Bike bike);
    }
    //Constructor del adaptador.s
    public MyItemRecyclerViewAdapter(Context context, List<BikesContent.Bike> items, OnItemClickListener listener) {
        mValues = items;
        mContext = context;
        mListener = listener;
    }
    //Al crear la vista infla el fragmento de item.
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_item, parent, false);
        return new ViewHolder(view);
    }
    //Con el viewHolder.
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        //Obtenemos cada bici de manera individual de la lista de bicis.
        BikesContent.Bike bike = mValues.get(position);
        //Establecemos los datos de la bici.
        holder.ownerTextView.setText(bike.getOwner());
        holder.descriptionTextView.setText(bike.getDescription());
        holder.locationTextView.setText(bike.getCity() + ", " + bike.getLocation());
        holder.bikeImageView.setImageBitmap(bike.getPhoto());
        //Le damos función al botón de email.
        holder.emailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = bike.getEmail();
                String subject = "Solicitud de bicicleta";
                String message = "Dear Mr/Mrs " + bike.getOwner() + ":\n" +
                        "I'd like to use your bike at " + bike.getLocation() + " (" + bike.getCity() + ")\n" +
                        "for the following date: " + BikesContent.selectedDate + "\n" +
                        "Can you confirm its availability?\n" +
                        "Kindest regards";
                //He cambiado el tipo de Action sendto a action send porque por algun motivo en action sendto no se me pasabna el cuerpo de mensaje ni el asunto.
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                //Ponemos el tipo mime para los correos.
                emailIntent.setType("message/rfc822");
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
                emailIntent.putExtra(Intent.EXTRA_TEXT, message);

                if (emailIntent.resolveActivity(view.getContext().getPackageManager()) != null) {
                    view.getContext().startActivity(Intent.createChooser(emailIntent, "Enviar email..."));
                } else {
                    Toast.makeText(view.getContext(), "No hay aplicaciones de correo disponibles", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //Le damos función al botón reserva.
        holder.reservaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarNotificacionReservaExitosa(bike);
            }
        });
        //Le damos función de botón al objeto bici que es un itemView.
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            //Al hacer click siempre que el listener no sea nulo realiza la acción de click en la bici.
            public void onClick(View v) {
                if(mListener != null){
                    mListener.onItemClick(bike);
                }
            }
        });


    }
    //Método para envíar la notificación de reserva de bici.
    private void enviarNotificacionReservaExitosa(BikesContent.Bike bike) {
        //Establecemos título y mensaje.
        String titulo = "Reserva Exitosa";
        String mensaje = "Has reservado la bici de " + bike.getOwner() + " con éxito.";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(mContext, CHANNEL_ID)
                //Le ponemos icono.
                .setSmallIcon(R.drawable.baseline_directions_bike_24)
                .setContentTitle(titulo)
                .setContentText(mensaje)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);
        //Comprobamos que tenemos los permisos de notificación, si no los tiene indica un mensaje.
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(mContext);
        if (ActivityCompat.checkSelfPermission(mContext, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(mContext,"Permisos de notificación denegados",Toast.LENGTH_SHORT).show();
        }
        //Creamos la notificacion.
        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }


    @Override
    public int getItemCount() {
        return mValues.size();
    }
    //Creamos los datos de cada objeto bici en el viewHolder.
    public class ViewHolder extends RecyclerView.ViewHolder {
        public final ImageView bikeImageView;
        public final TextView ownerTextView;
        public final TextView descriptionTextView;
        public final TextView locationTextView;
        public final Button emailButton;
        public final Button reservaButton;

        public ViewHolder(View view) {
            super(view);
            bikeImageView = view.findViewById(R.id.bikeImageView);
            ownerTextView = view.findViewById(R.id.ownerTextView);
            descriptionTextView = view.findViewById(R.id.descriptionTextView);
            locationTextView = view.findViewById(R.id.locationTextView);
            emailButton = view.findViewById(R.id.emailButton);
            reservaButton = view.findViewById(R.id.reservaButton);
        }
    }
}
