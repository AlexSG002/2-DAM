package com.example.sharemybike2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

//Clase con los contenidos de las bicis.
public class BikesContent {
    //Creamos una lista de objetos de tipo bici.
    public static List<Bike> ITEMS = new ArrayList<Bike>();
    //Declaramos un string para la fecha seleccionada.
    public static String selectedDate;
    //Método para cargar las bicis desde json.
    public static void loadBikesFromJSON(Context c) {
        String json = null;
        try {
            //Con esto comprobamos que el archivo json exista para ello creo un array de strings donde guarda todos los archivos del directorio para comparar el nombre del archivo.
            String[] archivosAssets = c.getAssets().list("");
            //Variable booleana para comprobar que existe el archivo.
            boolean archivoExiste = false;
            //Si los archivos no son nulos.
            if (archivosAssets != null) {
                //Comprueba que exista el archivo que buscamos dentro de los archivos.
                for (String nombreJSON : archivosAssets) {
                    if (nombreJSON.equalsIgnoreCase("bikeList.json")) {
                        archivoExiste = true;
                        break;
                    }
                }
            }
            //En caso de que no exista le muestra un mensaje al usuario.
            if (!archivoExiste) {
                Toast.makeText(c, "No se ha encontrado la base de datos de bicicletas.", Toast.LENGTH_LONG).show();
            }
            //Abrimos el json con un InputStream para obtener los datos.s
            InputStream is = c.getAssets().open("bikeList.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            //Leemos los datos.
            is.read(buffer);
            is.close();
            //Al string json que habíamos inicializado antes a null le introducimos los datos del buffer y la codificación UTF-8
            json = new String(buffer, "UTF-8");
            //Creamos un nuevo objeto json a través del string json.
            JSONObject jsonObject = new JSONObject(json);
            //Guardamos en un array de objetos json y obtenemos los datos del array.
            JSONArray couchList = jsonObject.getJSONArray("bike_list");
            for (int i = 0; i < couchList.length(); i++) {
                //Obtenemos cada dato de cada bici del array.
                JSONObject jsonCouch = couchList.getJSONObject(i);
                String owner = jsonCouch.getString("owner");
                String description = jsonCouch.getString("description");
                String city = jsonCouch.getString("city");
                String location = jsonCouch.getString("location");
                String email = jsonCouch.getString("email");
                Bitmap photo = null;
                //Decodificamos la foto.
                try {
                    photo = BitmapFactory.decodeStream(c.getAssets().open("images/" + jsonCouch.getString("image")));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //Añadimos la bici a la lista de bicis que hemos creado antes.
                ITEMS.add(new Bike(photo, owner, description, city, location, email));
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(c, "Error al procesar el archivo JSON", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(c, "Error al leer el archivo JSON", Toast.LENGTH_LONG).show();
        }
    }

    //Implementamos el parcelable para obtener los datos de la bici.
    public static class Bike implements Parcelable{
        private Bitmap photo;
        private String owner;
        private String description;
        private String city;
        private String location;
        private String email;

        protected Bike(Parcel in) {
            photo = in.readParcelable(Bitmap.class.getClassLoader());
            owner = in.readString();
            description = in.readString();
            city = in.readString();
            location = in.readString();
            email = in.readString();
        }

        public static final Creator<Bike> CREATOR = new Creator<Bike>() {
            @Override
            public Bike createFromParcel(Parcel in) {
                return new Bike(in);
            }

            @Override
            public Bike[] newArray(int size) {
                return new Bike[size];
            }
        };


        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public Bitmap getPhoto() {
            return photo;
        }

        public void setPhoto(Bitmap photo) {
            this.photo = photo;
        }

        public String getOwner() {
            return owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }


        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }



        public Bike(Bitmap photo, String owner, String description, String city, String location, String email) {
            this.photo = photo;
            this.owner = owner;
            this.description = description;
            this.city = city;
            this.location = location;
            this.email= email;
        }

        @Override
        public String toString() {
            return owner+" "+description;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(@NonNull Parcel dest, int flags) {
            dest.writeParcelable(photo, flags);
            dest.writeString(owner);
            dest.writeString(description);
            dest.writeString(city);
            dest.writeString(location);
            dest.writeString(email);
        }

    }
}
