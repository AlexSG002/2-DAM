package com.example.sharemybike2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
//Segundo fragmento al que navegaremos para mostrar la lista de bicis, implementamos el adaptador de bicis.
public class SecondFragment extends Fragment implements MyItemRecyclerViewAdapter.OnItemClickListener{
    //Declaramos un recyclerview y un adaptador.
    private RecyclerView recyclerView;
    private MyItemRecyclerViewAdapter adapter;
    //Constructor.s
    public SecondFragment() {
    }

    public static SecondFragment newInstance() {
        SecondFragment fragment = new SecondFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_second, container, false);
    }
    //Cuando se crea la vista obtenemos la lista de bicis, que comprueba si está vacía y si lo está la carga.
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (BikesContent.ITEMS.isEmpty()) {
            BikesContent.loadBikesFromJSON(getContext());
        }
        //Inicializamos el recyclerview a la que existe en el segundo fragmento.
        recyclerView = view.findViewById(R.id.recyclerViewSecondFragment);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        //Si la lista no está vacía establecemos el adaptador de recycler view a la vista.
        if (!BikesContent.ITEMS.isEmpty()) {
            adapter = new MyItemRecyclerViewAdapter(getContext(), BikesContent.ITEMS, this);
            recyclerView.setAdapter(adapter);
        } else {
            Toast.makeText(getContext(), "No se encontraron bicicletas.", Toast.LENGTH_SHORT).show();
        }
    }

    //Al hacer clic en el objeto bici pone la key del parcelable como "bike" y navega hacia bike details.
    @Override
    public void onItemClick(BikesContent.Bike bike) {
        Bundle bundle = new Bundle();
        bundle.putParcelable("bike", bike);
        NavController navController = Navigation.findNavController(getView());
        navController.navigate(R.id.action_SecondFragment_to_BikeDetails, bundle);
    }
}
