package com.example.sharemybike2;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    //Declaramos e inicializamos una variable de id de canal para el canal de notificaciones.
    private final String CHANNEL_ID = "canal_notificaciones_bikeshare";
    //Declaramos una variable final con el codigo del permiso de localización aceptada o 1001
    private static final int CODIGO_DE_PERMISO_DE_LOCALIZACION = 1001;
    //Declaramos e incializamos las variables que vamos a utilizar en la app.
    private ImageButton ImageButtonLocalizacion;
    private String email = "";
    private TextView direccionPostal;
    //Declaramos un FusedLocationProviderClient para poder obtener la localización del usuario.
    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Creamos el canal de notificaciones.
        crearCanalDeNotificaciones();

        //Inicializamos la direccionPostal al textView de ubicación y modificarlo.
        direccionPostal = findViewById(R.id.ubicacion);

        //Declaramos e inicializamos el botón de login para iniciar sesión
        Button loginButton = findViewById(R.id.btnLogin);
        //Declaramos e inicializamos el editText del email para poder obtener sus datos y validar su entrada
        EditText editTextEmail = findViewById(R.id.direccionContacto);
        //Le añadimos un evento OnClick al botón de login.
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = editTextEmail.getText().toString();
                //Comprobamos las entradas.
                if (comprobarEmail() && comprobarCodPostal()) {
                    //Iniciamos la Activity BikeActivity.
                    Intent intent = new Intent(MainActivity.this, BikeActivity.class);
                    startActivity(intent);
                }
            }
        });
        //Inicializamos el FusedLocationClient al proveedor del cliente de la app.
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        ImageButtonLocalizacion = findViewById(R.id.btnUbicacion);
        //Evento on click para el imagebutton de ubicación
        ImageButtonLocalizacion.setOnClickListener(new View.OnClickListener() {
            @Override
            //Comprobamos si tenemos los permisos de localización, si no, le indica al usuario si quiere aceptar los permisos, en caso de que no obtendremos la ubicación.
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    obtenerUbicacion();
                } else {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            CODIGO_DE_PERMISO_DE_LOCALIZACION);
                }
            }
        });
    }
    //Método para comprobar que el usuario haya cambiado el código postal, es decir que haya hecho clic en el botón de ubicación.
    private boolean comprobarCodPostal() {
        if (direccionPostal.getText().toString().equals("Dirección postal")) {
            Toast.makeText(MainActivity.this, "Indica tu dirección postal haciendo clic en el botón de ubicación", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
    //Método para comprobar que el usuario haya introducido un email correcto con una expresión regular.
    private boolean comprobarEmail() {
        if (email.isEmpty()) {
            Toast.makeText(MainActivity.this, "El email no puede estar vacío", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            if (!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                Toast.makeText(MainActivity.this, "Introduce un email correcto", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }
    //Método para obtener la ubicación del usuario
    private void obtenerUbicacion() {
        //Comprueba si tiene los permisos, si no, pues no hace nada.
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        // Obtenemos la última ubicación disponible del usuario.
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<android.location.Location>() {
                    @Override
                    public void onSuccess(android.location.Location location) {
                        if (location != null) {
                            // Al obtener la ubicación, pasamos las coordenadas a abrirMapa.
                            abrirMapa(location.getLatitude(), location.getLongitude());
                            //Obtenemos el código postal con la longitud y latitud.
                            obtenerCodigoPostal(location.getLatitude(), location.getLongitude());
                        } else {
                            Toast.makeText(MainActivity.this, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    //Método para obtener el código postal y establecerlo en el textview.
    private void obtenerCodigoPostal(double latitud, double longitud) {
        //Declaramos e inicializamos un nuevo geocoder para esta activity con el Locale por defecto.
        Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
        try {
            //Obtenemos la lista de direcciones del geocoder con la latitud y la longitud y limitamos los resultados a uno.
            List<Address> addresses = geocoder.getFromLocation(latitud, longitud, 1);
            //Si no esta vacío o es nulo.
            if (addresses != null && !addresses.isEmpty()) {
                //Obtenemos esa ubicación y su código postal.
                Address address = addresses.get(0);
                String codigoPostal = address.getPostalCode();
                if (codigoPostal != null) {
                    direccionPostal.setText(codigoPostal);
                } else {
                    direccionPostal.setText("Código postal no disponible");
                }
            } else {
                direccionPostal.setText("No se encontró la dirección");
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error al obtener el código postal", Toast.LENGTH_SHORT).show();
        }
    }
    //Método para abrir el mapa, utilizamos la latitud y la longitud para abrir google maps en la localización en la que nos encontremos con Uri.
    private void abrirMapa(double latitud, double longitud) {
        Uri gmmIntentUri = Uri.parse("geo:" + latitud + "," + longitud + "?q=" + latitud + "," + longitud);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            Toast.makeText(this, "No se encontró ninguna aplicación de mapas", Toast.LENGTH_SHORT).show();
        }
    }
    //Método para los resultados de la obtención de permisos.B
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CODIGO_DE_PERMISO_DE_LOCALIZACION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                obtenerUbicacion();
            } else {
                Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }
    //Método para crear el canal de notificaciones.
    private void crearCanalDeNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence nombre = "Canal de Notificaciones BikeShare";
            String descripcion = "Canal para notificaciones de reservas exitosas de bicicletas";
            int importancia = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel canal = new NotificationChannel(CHANNEL_ID, nombre, importancia);
            canal.setDescription(descripcion);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(canal);
        }
    }

}
