package com.example.sharemybike2;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.sharemybike2.databinding.ActivityBikeBinding;

public class BikeActivity extends AppCompatActivity {
    //Declaramo las variables para la configuración de la app bar y del binding.
    private AppBarConfiguration appBarConfiguration;
    private ActivityBikeBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Inicializamos el binding al inflador de layout para poner la activity_bike en pantalla con la vista del calendario.
        binding = ActivityBikeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        //Establecemos la toolbar en el binding.
        setSupportActionBar(binding.toolbar);

        //Declaramos e inicializamos el NavController para navegar entre fragmentos.
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_bike);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        //Cargamos los archivos de json.
        BikesContent.loadBikesFromJSON(this);

    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_bike);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}