package com.example.sharemybike2;

import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FirstFragment extends Fragment {
    //Declaramos un nuevo CalendarView para seleccionar la fecha
    private CalendarView calendarView;
    private TextView textViewFecha;
    private final int CODIGO_PERMISO_NOTIFICACIONES = 1;
    Button buttonConfirmar;
    //Inflamos el calendar view al fragmento.
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        View vista = inflater.inflate(R.layout.fragment_first, container, false);
        buttonConfirmar = vista.findViewById(R.id.buttonConfirmar);
        calendarView = vista.findViewById(R.id.calendarView);
        textViewFecha = vista.findViewById(R.id.selectedDateTextView);
        //Establecemos los limites del calendario.
        limitesCalendario();
        //Evento que detecta si cambia la fecha y cambia el textview de la fecha que indica la fecha seleccionada
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String fechaSeleccionada = dayOfMonth + "/" + (month + 1) + "/" + year;
                textViewFecha.setText("Fecha seleccionada: " + fechaSeleccionada);
                //Establecemos la fecha de BikesContent como la fecha seleccionada para que luego salga en los mensajes que enviemos.
                BikesContent.selectedDate = fechaSeleccionada;
            }
        });
        //Obrtenemos la fecha de hoy con el formato dias, meses años y el Locale de hoy, al que le aplicamos el nuevo formato y creamos una nueva fecha a string.
        String fechaHoy = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        textViewFecha.setText("Fecha seleccionada: " + fechaHoy);
        //Establecemos la fecha de bikes content a la fecha de hoy.
        BikesContent.selectedDate = fechaHoy;
        //Evento OnClick para el botón de confirmar
        buttonConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Una vez confirmado navegamos del primer fragmento a second fragment con NavController.
                NavController navController = Navigation.findNavController(view);
                navController.navigate(R.id.action_FirstFragment_to_SecondFragment);
                solicitarPermisoNotificaciones();

            }
        });
        //Devolvemos la vista para que la apliquemos luego
        return vista;
    }
    //Método que utilizamos para calcular la fecha mínima para elegir una bici y la máxima, yo he puesto un año.
    private void limitesCalendario() {
        //Obtenemos los milisegundos del día de hoy y lo llamamos hoy de tipo long
        long hoy = System.currentTimeMillis();
        //Para obtener la fecha de hoy más un año calculamos los milisegundos de un año y se lo sumamos al día de hoy
        long fechaMaxima = hoy + (365L * 24 * 60 * 60 * 1000);
        //Establecemos la fecha mínima y máxima.
        calendarView.setMinDate(hoy);
        calendarView.setMaxDate(fechaMaxima);
    }
    //Método para solicitar el permiso de notificaciones.
    private void solicitarPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                        CODIGO_PERMISO_NOTIFICACIONES
                );
            }
        }

    }
    //Al obtener el permiso no hace nada porque en este fragmento no lo necesitamos, pero si no los das te enseña un mensaje.
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CODIGO_PERMISO_NOTIFICACIONES) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else {
                Toast.makeText(getContext(), "Permiso de notificaciones denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }

}
